import { FunctionComponent } from "react";

const Loader: FunctionComponent = () => {
  return <h1>Loading....</h1>;
};

export default Loader;
