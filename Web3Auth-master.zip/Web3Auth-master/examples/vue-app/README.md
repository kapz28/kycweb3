## Web3Auth Vue Example

- ### Pre requirements:-

  - Install yarn:- `npm i -g yarn`

  - Build packages:-

    - Go to project root folder: `cd ../../`
    - Install deps: `yarn` && `yarn run bootstrap`
    - Build project:- `yarn run build`

  - Run the example:-

    - Go to example: `cd examples/vue-app`
    - Install deps: `npm install`
    - Run example:- `npm run serve`
