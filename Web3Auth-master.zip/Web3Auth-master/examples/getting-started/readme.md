## Basic integration example for Web3Auth

### Pre Requirements

- `npm i -g http-server`


### Run Ethereum Example

- `http-server eth/`


### Run Solana Example

- `http-server solana/`