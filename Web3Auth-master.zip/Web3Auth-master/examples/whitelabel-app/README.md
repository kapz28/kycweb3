# Whitelabel
This app showcase customizable ui for web3auth. Running the app generates sample configuration code.

## Project setup
```
npm install
```

### Compiles and hot-reloads for development
```
npm run serve
```