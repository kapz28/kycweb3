module.exports = {
  presets: ["@babel/env", ["@babel/preset-react", { runtime: "automatic" }], "@babel/typescript"],
};
