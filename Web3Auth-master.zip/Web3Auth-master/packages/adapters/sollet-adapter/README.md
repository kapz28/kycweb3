# `@web3auth/sollet-wallet-adapter`

> TODO: description
