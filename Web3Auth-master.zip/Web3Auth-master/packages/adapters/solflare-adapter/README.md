# `@web3auth/solflare-adapter`

> TODO: description
