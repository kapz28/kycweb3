# `@web3auth/slope-adapter`

> TODO: description
