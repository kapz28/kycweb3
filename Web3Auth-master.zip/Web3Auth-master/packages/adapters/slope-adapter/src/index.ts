export * from "./slopeAdapter";
