import loglevel from "loglevel";

export default loglevel.getLogger("web3auth-logger");
