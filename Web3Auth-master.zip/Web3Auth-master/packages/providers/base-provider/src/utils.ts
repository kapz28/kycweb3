import getCreateRandomId from "json-rpc-random-id";
export const createRandomId = getCreateRandomId();
