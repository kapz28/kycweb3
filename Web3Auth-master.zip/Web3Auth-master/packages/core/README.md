# `@web3auth/core`

[![npm version](https://img.shields.io/npm/v/@web3auth/core?label=%22%22)](https://www.npmjs.com/package/@web3auth/core/v/latest)
[![minzip](https://img.shields.io/bundlephobia/minzip/@web3auth/core?label=%22%22)](https://bundlephobia.com/result?p=@web3auth/core@latest)

Provides the core logic for handling adapters within web3auth.
This package acts as a manager for all the adapters.
You should use this package to build your custom login UI on top of web3auth.
